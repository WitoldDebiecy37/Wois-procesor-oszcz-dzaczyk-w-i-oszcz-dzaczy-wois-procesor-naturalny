# Skynet Documentation

1. [Modules - RAG Assistant](assistant.md)
2. [Modules - Summaries](summaries_module.md)
3. [Modules - Streaming Whisper Live Transcription](streaming_whisper_module.md)
4. [Config - Environment Variables](env_vars.md)
5. [Authentication](auth.md)
6. [Monitoring](monitoring.md)
7. [Demos](../demos/)
