RUNNING_RAG_KEY = 'rag:running'
ERROR_RAG_KEY = 'rag:error'
STORED_RAG_KEY = 'rag:stored'

supported_files = ['.pdf', '.doc', '.docx', '.txt', '.ppt', '.pptx', '.rtf', '.epub', '.odt']
