---
name: Readme First
about: Issues is bug report only
title: ''
labels: ''
assignees: ''

---

The **Issues** is for bug report only.

Goto **Discussions** for feature request , questions, etc.

**Update to master branch HEAD first**, and

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior.

**Additional context**
Add any other context about the problem here.
