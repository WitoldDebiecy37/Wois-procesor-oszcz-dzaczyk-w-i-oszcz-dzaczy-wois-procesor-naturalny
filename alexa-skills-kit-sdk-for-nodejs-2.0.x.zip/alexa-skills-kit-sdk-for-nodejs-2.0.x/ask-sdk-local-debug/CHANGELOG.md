# Change Log

# 1.1.0 (2020-11-10)

This release contains the following changes : 

- Adding support for EU and FE.

# 1.0.0 (2020-07-21)

This release contains the following changes : 

- Initial release for local development support for ASK SDK for Node.js.
