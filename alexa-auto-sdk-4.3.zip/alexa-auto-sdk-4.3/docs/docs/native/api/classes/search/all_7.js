var searchData=
[
  ['hardware_5farch',['HARDWARE_ARCH',['../classaace_1_1vehicle_1_1config_1_1_vehicle_configuration.html#ae4b58f9dd91c015120344afcfc6649e4a369dd85de22dfb81108b4fbd1d84203e',1,'aace::vehicle::config::VehicleConfiguration']]],
  ['hold_5fto_5ftalk',['HOLD_TO_TALK',['../classaace_1_1alexa_1_1_speech_recognizer_engine_interface.html#a32b21eebeb377059d5548e7297c0846bab8c3869bf1fc2cdd2f2234030bbd364c',1,'aace::alexa::SpeechRecognizerEngineInterface']]],
  ['holdtotalk',['holdToTalk',['../classaace_1_1alexa_1_1_speech_recognizer.html#aa2859cbc2a49609ba8027f912d373692',1,'aace::alexa::SpeechRecognizer']]]
];
