# AASB Message Reference

Use the AASB message interfaces to provide platform-specific deep integration to the Auto SDK Engine. 

The AASB message reference is organized by module and interface name.